package actividad05;

import actividad05.artistas.Artista;
import actividad05.artistas.Dibujante;
import actividad05.artistas.Musico;

public class TestArtista {
    public static void main(String[] args) {
        Artista artista = new Artista();

        artista.setNombre("Banksy");
        artista.setAñoNacimiento(1974);
        artista.setDni("Y0750982-T");
        artista.setSexo('H');

        System.out.println(artista.toString());

        Dibujante dibujante = new Dibujante("12/08/1988", "Untitled", 110500000);
        dibujante.setNombre("Jean-Michel Basquiat");
        dibujante.setAñoNacimiento(1960);
        dibujante.setDni("898989W");
        dibujante.setSexo('H');

        System.out.println(dibujante.toString());

        Musico musico = new Musico("Adele", 1988, 'M',"123456W","http://www.adele.com", "25");

        System.out.println(musico.toString());

        musico.setCancion();
        musico.muestraCanciones();
    }
}
